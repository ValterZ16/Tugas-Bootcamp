#include <stdio.h>

int main () {
	
	int x;
	
	scanf ("%d", &x);
		
	if (x < 10) {
		printf ("1");
	} else if (x < 100) {
		printf ("2");
	} else if (x < 1000) {
		printf ("3");
	} else {
		printf ("More than 3 digits");
	}
	
	return 0;
}

#include <stdio.h>

int main () {
	
	int x;
	
	scanf ("%d", &x);
	printf ("%d", x);
	
	return 0;
}

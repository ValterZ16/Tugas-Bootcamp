#include <stdio.h>

int main () {
	
	int x, y;
	
	scanf ("%d\n %d", &x, &y);
	
	if (x * y < 2 * (x + y)) {
		printf ("Peri\n%d", 2 * (x + y));
	} else if (x * y > 2 * (x + y)) {
		printf ("Area\n%d", x * y);
	} else {
		printf ("Eq\n%d", x * y);
	}
	
	return 0;
}

#include <stdio.h>

int main () {
	
	int x, y;
	
	scanf ("%d\n%d", &x, &y);
	
	if (x > y) {
		printf ("%d", x - y);
	} else {
		printf ("%d", x + y);
	}
	
	return 0;
}
